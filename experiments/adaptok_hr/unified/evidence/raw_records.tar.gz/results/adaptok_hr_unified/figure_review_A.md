# First-seed rendered review

Eight single-panel figures inspected: six native rate-distortion/color panels and both completed Pilot training curves. All four arms and four actual rate points are visible; method colors/styles are consistent. No curve exclusions or simulated uncertainty. Native LPIPS and DISTS show a real tradeoff, not a common improvement. Color error and variance are reported separately. The long training ylabel was shortened; the trailing 25-update pooled-MSE smoothing is documented in the figure contract. Final exports must be re-rendered and audited after this label change.

The source preflight warnings are intentional: PNG is a report preview alongside editable PDF/SVG (no TIFF submission was requested); each seed is plotted separately, so no across-seed aggregate error bar is invented. Single-panel alignment is not applicable. Actual PDF glyph/collision checks passed for the first rendering.

Second-seed A-only panels: manually inspected all six metric panels in figures_A_review.png. All four budget points, labels and legend styles are visible, with no clipping/overlap. Metric-specific regressions and tradeoffs agree with the underlying summaries; no points were removed.
