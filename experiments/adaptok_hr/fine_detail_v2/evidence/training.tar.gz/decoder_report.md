## 匹配 Decoder 消融

各组从同种子第 1000 步的共同父模型起步，再走相同的 300 次更新。C0 同步续训 R00。第一种子选中 D3，第二种子复验该方案和 D0。

| 种子 | 模型 | K2048 PSNR | LPIPS | DISTS | 内容门槛 | 采用门槛 | 未过项目 |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | D0 | 18.97289 | 0.797971 | 0.605937 | True | False | perception_with_budget, absolute_quality, protected |
| 1 | D1 | 18.94567 | 0.800078 | 0.606434 | True | False | perception_with_budget, absolute_quality, protected |
| 1 | D2 | 18.80511 | 0.807390 | 0.600781 | True | False | perception_with_budget, absolute_quality, protected |
| 1 | D3 | 19.00589 | 0.803121 | 0.599636 | True | False | perception_with_budget, absolute_quality, protected |
| 2 | D0 | 18.31575 | 0.769112 | 0.599756 | True | False | perception_with_budget, absolute_quality, protected |
| 2 | D3 | 18.62519 | 0.773429 | 0.588573 | True | False | perception_with_budget, absolute_quality, protected |

下表给出 D3 相对同种子同步数 C0 的逐档差值。晚期 K2048 只比较第 48 帧起的相同画面。

| 种子 | 预算 / 帧段 | ΔPSNR (dB) | ΔLPIPS | ΔDISTS |
|---|---|---:|---:|---:|
| 1 | 256 | +0.17928 | +0.022458 | -0.009133 |
| 1 | 512 | +0.21940 | +0.018338 | -0.010141 |
| 1 | 1024 | +0.44303 | +0.020465 | -0.016285 |
| 1 | late_2048 | +0.86845 | +0.039773 | -0.030836 |
| 2 | 256 | +0.31364 | +0.003716 | -0.009637 |
| 2 | 512 | +0.15443 | +0.004231 | -0.009510 |
| 2 | 1024 | +0.19161 | +0.004154 | -0.011669 |
| 2 | late_2048 | +0.19920 | +0.005961 | -0.016679 |

双种子的整体画质门槛未同时满足。此处结束模型扩展，后面的吞吐数字为所测模型原路径。
